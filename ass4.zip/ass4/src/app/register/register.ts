import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './register.html'
})
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html'
})
export class RegisterComponent {

  user = {
    name: '',
    email: '',
    mobile: '',
    password: '',
    confirmPassword: ''
  };

  message = '';

  register() {

    if (this.user.password !== this.user.confirmPassword) {
      this.message = "Passwords do not match!";
      return;
    }

    // Save to localStorage
    localStorage.setItem('user', JSON.stringify(this.user));

    this.message = "Registration Successful!";
  }
}