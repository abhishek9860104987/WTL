import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.html'
})
export class Login {

  email = '';
  password = '';
  message = '';

  login() {

    const storedUser = JSON.parse(localStorage.getItem('user') || '{}');

    if (this.email === storedUser.email &&
        this.password === storedUser.password) {

      this.message = "Login Successful!";
    } else {
      this.message = "Invalid Email or Password!";
    }
  }
}