import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Login } from './login/login';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule, Login],
  templateUrl: './app.html'
  
})
export class App {

  user = {
    name: '',
    email: '',
    mobile: '',
    password: '',
    confirmPassword: ''
  };

  message = '';

  register() {
    if (this.user.password !== this.user.confirmPassword) {
      this.message = "Passwords do not match!";
      return;
    }

    localStorage.setItem('user', JSON.stringify(this.user));
    this.message = "Registration Successful!";
  }
}